package com.example.demodictionary;

public class Time {

}
