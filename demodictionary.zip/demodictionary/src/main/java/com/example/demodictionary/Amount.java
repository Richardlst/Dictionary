package com.example.demodictionary;

public class Amount {

}
