package com.example.demodictionary;

public class Analyze {

}
