package com.example.demodictionary;

public class Vocab {

}
